(() => {
	const themeScript = document.createElement("SCRIPT");
	themeScript.setAttribute("type", "text/javascript");
	themeScript.setAttribute("src", "https://comfy-themes.github.io/Spicetify/Comfy/theme.script.js");
	document.head.appendChild(themeScript);
})();
